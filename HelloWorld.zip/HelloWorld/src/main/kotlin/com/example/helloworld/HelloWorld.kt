package com.example.helloworld

import com.aliucord.entities.Plugin

class HelloWorld : Plugin() {
    override fun start(context: Context) {
        logger.info("Hello World!")
    }

    override fun stop(context: Context) {}
}