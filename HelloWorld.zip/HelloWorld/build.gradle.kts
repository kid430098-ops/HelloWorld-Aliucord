plugins {
    kotlin("jvm") version "1.9.24"
}

group = "com.example.helloworld"
version = "1.0.0"

repositories {
    mavenCentral()
}

dependencies {
    implementation(kotlin("stdlib"))
}